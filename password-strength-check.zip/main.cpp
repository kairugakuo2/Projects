#include <iostream>
#include <string>
#include <cctype>
using namespace std;

string checkPassword(string pswrd, int size){
    string password = pswrd;
    int passSize = size;

    //password requirements
    bool eightCharacters = false;
    bool uppercase = false;
    bool lowercase = false;
    bool oneNumber = false;

    bool requirements = false;
    
    //string phrases for passwords
    string doesNotMeet = "Password does not meet the requirements...";
    string weak = "Password is weak.";
    string strong = "Password is strong!";
    string vStrong = "Password is very strong!";
    string response;

    // check characters
    if (passSize >= 8){
        eightCharacters = true;}
    // check if any uppercase
    for (int i = 0; i<size; i++){
        if (isupper(password[i])){ uppercase = true;break;}}
    //check if any lowercase
    for (int i = 0; i<size; i++){
        if (islower(password[i])){ lowercase = true;break;}}
    //check if any number
    for (int i = 0; i<size; i++){
        if (isdigit(password[i])){ oneNumber = true; break;}}
    
    //check if all requirements met
    if (eightCharacters == true && uppercase == true && lowercase == true && oneNumber == true){
        requirements = true;
    } else {
        response = doesNotMeet;
    }
    //check if weak
    if (requirements == true && passSize <= 10){
        response = weak;
        return response;
    }
    //check if strong
    if (requirements == true && passSize <= 15 ){
        response = strong;
        return response;
    }
    //check if very strong
    if (requirements == true && passSize > 15 ){
        response = vStrong;
    }
 return response;
}


int main(){
    string password;
    int size;
    string response;
    
    cout << "Enter your password: ";
    cin >> password;
    size = password.length();
    
    response = checkPassword(password, size);
    
    cout << response;
}